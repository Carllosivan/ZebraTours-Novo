<?php
/**
 * Zebra Tours Moçambique - Configurações Globais da Aplicação
 * Arquitetura Limpa PHP MVC Própria
 */

declare(strict_types=1);

// Definir caminhos base do sistema
define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('CONFIG_PATH', BASE_PATH . '/config');
define('PUBLIC_PATH', BASE_PATH . '/public');
define('STORAGE_PATH', BASE_PATH . '/public/uploads');

// Carregar variáveis de ambiente simples se existir .env
$envFile = BASE_PATH . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }
        if (str_contains($line, '=')) {
            [$key, $value] = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value, " \t\n\r\0\x0B\"'");
            if (!array_key_exists($key, $_SERVER) && !array_key_exists($key, $_ENV)) {
                putenv("{$key}={$value}");
                $_ENV[$key] = $value;
                $_SERVER[$key] = $value;
            }
        }
    }
}

// Configurações gerais
return [
    'app_name' => getenv('APP_NAME') ?: 'Zebra Tours Moçambique',
    'app_env' => getenv('APP_ENV') ?: 'production', // 'development' ou 'production'
    'app_url' => getenv('APP_URL') ?: 'http://localhost:3000',
    'app_debug' => (getenv('APP_ENV') === 'development'),
    'timezone' => 'Africa/Maputo',
    'currency' => 'MT',
    'contact' => [
        'phone' => '+258 85 104 1826',
        'whatsapp' => '+258 85 104 1826',
        'email' => 'info@zebratours.co.mz',
        'address' => 'Rua Marconi 134 R/C, Maputo, Moçambique',
        'slogan' => 'O seu próximo destino começa aqui!',
    ],
];
