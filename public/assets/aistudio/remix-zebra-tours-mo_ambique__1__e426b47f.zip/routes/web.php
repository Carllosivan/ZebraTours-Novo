<?php
/**
 * Zebra Tours Moçambique - Definição de Rotas Web (Clean MVC)
 * Roteamento centralizado para Front Controller
 */

declare(strict_types=1);

use App\Controllers\DestinationController;
use App\Controllers\MediaController;
use App\Core\Response;
use App\Core\Database;

/** @var \App\Core\Router $router */

// 1. Página Inicial e Catálogo de Destinos (MVC)
$router->get('/', [DestinationController::class, 'index']);
$router->get('/destinos', [DestinationController::class, 'index']);
$router->get('/destinos/{slug}', [DestinationController::class, 'show']);

// 2. Módulo de Biblioteca Multimédia (CMS MVC)
$router->get('/media', [MediaController::class, 'index']);
$router->get('/media/upload', [MediaController::class, 'create']);
$router->post('/media/upload', [MediaController::class, 'store']);
$router->post('/media/delete', [MediaController::class, 'delete']);

// 3. Endpoints JSON (API)
$router->get('/api/destinos', [DestinationController::class, 'apiList']);
$router->get('/api/pacotes', function() {
    $db = Database::getConnection();
    $packages = $db->query("
        SELECT p.*, d.name AS destination_name, d.country
        FROM packages p
        LEFT JOIN destinations d ON d.id = p.primary_destination_id
        WHERE p.status != 'rascunho'
        ORDER BY p.is_featured DESC
    ")->fetchAll();
    return Response::json($packages);
});

$router->get('/api/settings', function() {
    $db = Database::getConnection();
    $settings = $db->query("SELECT setting_key, setting_value FROM settings")->fetchAll();
    $result = [];
    foreach ($settings as $s) {
        $result[$s['setting_key']] = $s['setting_value'];
    }
    return Response::json($result);
});
